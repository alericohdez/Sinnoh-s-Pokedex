// js/crud.js
// CRUD module: read and create Pokemon entries using localStorage.
// Variables/functions: camelCase. JS classes (if any) would be PascalCase.

const STORAGE_KEY = 'sinnoh_pokedex_v1';

/**
 * Load initial data if nothing is in storage.
 * Data is real Pokémon names from Sinnoh — not lorem.
 */
function loadInitialData() {
  let defaultData = [
    {
      "name": "Turtwig",
      "number": 387,
      "type": "grass",
      "image": "images/turtwig.jpg"
    },
    {
      "name": "Grotle",
      "number": 388,
      "type": "grass",
      "image": "images/grotle.jpg"
    },
    {
      "name": "Torterra",
      "number": 389,
      "type": "grass/ground",
      "image": "images/torterra.jpg"
    },
    {
      "name": "Chimchar",
      "number": 390,
      "type": "fire",
      "image": "images/chimchar.jpg"
    },
    {
      "name": "Monferno",
      "number": 391,
      "type": "fire/fighting",
      "image": "images/monferno.jpg"
    },
    {
      "name": "Infernape",
      "number": 392,
      "type": "fire/fighting",
      "image": "images/infernape.jpg"
    },
    {
      "name": "Piplup",
      "number": 393,
      "type": "water",
      "image": "images/piplup.jpg"
    },
    {
      "name": "Prinplup",
      "number": 394,
      "type": "water",
      "image": "images/prinplup.jpg"
    },
    {
      "name": "Empoleon",
      "number": 395,
      "type": "water/steel",
      "image": "images/empoleon.jpg"
    },
    {
      "name": "Starly",
      "number": 396,
      "type": "normal/flying",
      "image": "images/starly.jpg"
    },
    {
      "name": "Staravia",
      "number": 397,
      "type": "normal/flying",
      "image": "images/staravia.jpg"
    },
    {
      "name": "Staraptor",
      "number": 398,
      "type": "normal/flying",
      "image": "images/staraptor.jpg"
    },
    {
      "name": "Bidoof",
      "number": 399,
      "type": "normal",
      "image": "images/bidoof.jpg"
    },
    {
      "name": "Bibarel",
      "number": 400,
      "type": "normal/water",
      "image": "images/bibarel.jpg"
    },
    {
      "name": "Kricketot",
      "number": 401,
      "type": "bug",
      "image": "images/kricketot.jpg"
    },
    {
      "name": "Kricketune",
      "number": 402,
      "type": "bug",
      "image": "images/kricketune.jpg"
    },
    {
      "name": "Shinx",
      "number": 403,
      "type": "electric",
      "image": "images/shinx.jpg"
    },
    {
      "name": "Luxio",
      "number": 404,
      "type": "electric",
      "image": "images/luxio.jpg"
    },
    {
      "name": "Luxray",
      "number": 405,
      "type": "electric",
      "image": "images/luxray.jpg"
    },
    {
      "name": "Budew",
      "number": 406,
      "type": "grass/poison",
      "image": "images/budew.jpg"
    },
    {
      "name": "Roserade",
      "number": 407,
      "type": "grass/poison",
      "image": "images/roserade.jpg"
    },
    {
      "name": "Cranidos",
      "number": 408,
      "type": "rock",
      "image": "images/cranidos.jpg"
    },
    {
      "name": "Rampardos",
      "number": 409,
      "type": "rock",
      "image": "images/rampardos.jpg"
    },
    {
      "name": "Shieldon",
      "number": 410,
      "type": "rock/steel",
      "image": "images/shieldon.jpg"
    },
    {
      "name": "Bastiodon",
      "number": 411,
      "type": "rock/steel",
      "image": "images/bastiodon.jpg"
    },
    {
      "name": "Burmy",
      "number": 412,
      "type": "bug",
      "image": "images/burmy.jpg"
    },
    {
      "name": "Wormadam",
      "number": 413,
      "type": "bug/grass", // Puede variar (Planta, Tierra, Acero)
      "image": "images/wormadam.jpg"
    },
    {
      "name": "Mothim",
      "number": 414,
      "type": "bug/flying",
      "image": "images/mothim.jpg"
    },
    {
      "name": "Combee",
      "number": 415,
      "type": "bug/flying",
      "image": "images/combee.jpg"
    },
    {
      "name": "Vespiquen",
      "number": 416,
      "type": "bug/flying",
      "image": "images/vespiquen.jpg"
    },
    {
      "name": "Pachirisu",
      "number": 417,
      "type": "electric",
      "image": "images/pachirisu.jpg"
    },
    {
      "name": "Buizel",
      "number": 418,
      "type": "water",
      "image": "images/buizel.jpg"
    },
    {
      "name": "Floatzel",
      "number": 419,
      "type": "water",
      "image": "images/floatzel.jpg"
    },
    {
      "name": "Cherubi",
      "number": 420,
      "type": "grass",
      "image": "images/cherubi.jpg"
    },
    {
      "name": "Cherrim",
      "number": 421,
      "type": "grass",
      "image": "images/cherrim.jpg"
    },
    {
      "name": "Shellos",
      "number": 422,
      "type": "water",
      "image": "images/shellos.jpg"
    },
    {
      "name": "Gastrodon",
      "number": 423,
      "type": "water/ground",
      "image": "images/gastrodon.jpg"
    },
    {
      "name": "Aipom",
      "number": 424,
      "type": "normal",
      "image": "images/aipom.jpg"
    },
    {
      "name": "Ambipom",
      "number": 425,
      "type": "normal",
      "image": "images/ambipom.jpg"
    },
    {
      "name": "Drifloon",
      "number": 426,
      "type": "ghost/flying",
      "image": "images/drifloon.jpg"
    },
    {
      "name": "Drifblim",
      "number": 427,
      "type": "ghost/flying",
      "image": "images/drifblim.jpg"
    },
    {
      "name": "Buneary",
      "number": 428,
      "type": "normal",
      "image": "images/buneary.jpg"
    },
    {
      "name": "Lopunny",
      "number": 429,
      "type": "normal",
      "image": "images/lopunny.jpg"
    },
    {
      "name": "Mismagius",
      "number": 430,
      "type": "ghost",
      "image": "images/mismagius.jpg"
    },
    {
      "name": "Honchkrow",
      "number": 431,
      "type": "dark/flying",
      "image": "images/honchkrow.jpg"
    },
    {
      "name": "Glameow",
      "number": 432,
      "type": "normal",
      "image": "images/glameow.jpg"
    },
    {
      "name": "Purugly",
      "number": 433,
      "type": "normal",
      "image": "images/purugly.jpg"
    },
    {
      "name": "Chingling",
      "number": 434,
      "type": "psychic",
      "image": "images/chingling.jpg"
    },
    {
      "name": "Stunky",
      "number": 435,
      "type": "poison/dark",
      "image": "images/stunky.jpg"
    },
    {
      "name": "Skuntank",
      "number": 436,
      "type": "poison/dark",
      "image": "images/skuntank.jpg"
    },
    {
      "name": "Bronzor",
      "number": 437,
      "type": "steel/psychic",
      "image": "images/bronzor.jpg"
    },
    {
      "name": "Bronzong",
      "number": 438,
      "type": "steel/psychic",
      "image": "images/bronzong.jpg"
    },
    {
      "name": "Bonsly",
      "number": 439,
      "type": "rock",
      "image": "images/bonsly.jpg"
    },
    {
      "name": "Mime Jr.",
      "number": 440,
      "type": "psychic/fairy",
      "image": "images/mimejr.jpg"
    },
    {
      "name": "Happiny",
      "number": 441,
      "type": "normal",
      "image": "images/happiny.jpg"
    },
    {
      "name": "Chatot",
      "number": 442,
      "type": "normal/flying",
      "image": "images/chatot.jpg"
    },
    {
      "name": "Spiritomb",
      "number": 443,
      "type": "ghost/dark",
      "image": "images/spiritomb.jpg"
    },
    {
      "name": "Gible",
      "number": 444,
      "type": "dragon/ground",
      "image": "images/gible.jpg"
    },
    {
      "name": "Gabite",
      "number": 445,
      "type": "dragon/ground",
      "image": "images/gabite.jpg"
    },
    {
      "name": "Garchomp",
      "number": 446,
      "type": "dragon/ground",
      "image": "images/garchomp.jpg"
    },
    {
      "name": "Munchlax",
      "number": 447,
      "type": "normal",
      "image": "images/munchlax.jpg"
    },
    {
      "name": "Riolu",
      "number": 448,
      "type": "fighting",
      "image": "images/riolu.jpg"
    },
    {
      "name": "Lucario",
      "number": 449,
      "type": "fighting/steel",
      "image": "images/lucario.jpg"
    },
    {
      "name": "Hippopotas",
      "number": 450,
      "type": "ground",
      "image": "images/hippopotas.jpg"
    },
    {
      "name": "Hippowdon",
      "number": 451,
      "type": "ground",
      "image": "images/hippowdon.jpg"
    },
    {
      "name": "Skorupi",
      "number": 452,
      "type": "poison/bug",
      "image": "images/skorupi.jpg"
    },
    {
      "name": "Drapion",
      "number": 453,
      "type": "poison/dark",
      "image": "images/drapion.jpg"
    },
    {
      "name": "Croagunk",
      "number": 454,
      "type": "poison/fighting",
      "image": "images/croagunk.jpg"
    },
    {
      "name": "Toxicroak",
      "number": 455,
      "type": "poison/fighting",
      "image": "images/toxicroak.jpg"
    },
    {
      "name": "Carnivine",
      "number": 456,
      "type": "grass",
      "image": "images/carnivine.jpg"
    },
    {
      "name": "Finneon",
      "number": 457,
      "type": "water",
      "image": "images/finneon.jpg"
    },
    {
      "name": "Lumineon",
      "number": 458,
      "type": "water",
      "image": "images/lumineon.jpg"
    },
    {
      "name": "Mantyke",
      "number": 459,
      "type": "water/flying",
      "image": "images/mantyke.jpg"
    },
    {
      "name": "Snover",
      "number": 460,
      "type": "grass/ice",
      "image": "images/snover.jpg"
    },
    {
      "name": "Abomasnow",
      "number": 461,
      "type": "grass/ice",
      "image": "images/abomasnow.jpg"
    },
    {
      "name": "Weavile",
      "number": 462,
      "type": "dark/ice",
      "image": "images/weavile.jpg"
    },
    {
      "name": "Magmortar",
      "number": 463,
      "type": "fire",
      "image": "images/magmortar.jpg"
    },
    {
      "name": "Electivire",
      "number": 464,
      "type": "electric",
      "image": "images/electivire.jpg"
    },
    {
      "name": "Togekiss",
      "number": 465,
      "type": "fairy/flying", // En Generación IV era Normal/Flying
      "image": "images/togekiss.jpg"
    },
    {
      "name": "Yanmega",
      "number": 466,
      "type": "bug/flying",
      "image": "images/yanmega.jpg"
    },
    {
      "name": "Leafeon",
      "number": 467,
      "type": "grass",
      "image": "images/leafeon.jpg"
    },
    {
      "name": "Glaceon",
      "number": 468,
      "type": "ice",
      "image": "images/glaceon.jpg"
    },
    {
      "name": "Gliscor",
      "number": 469,
      "type": "ground/flying",
      "image": "images/gliscor.jpg"
    },
    {
      "name": "Mamoswine",
      "number": 470,
      "type": "ice/ground",
      "image": "images/mamoswine.jpg"
    },
    {
      "name": "Porygon-Z",
      "number": 471,
      "type": "normal",
      "image": "images/porygonz.jpg"
    },
    {
      "name": "Gallade",
      "number": 472,
      "type": "psychic/fighting",
      "image": "images/gallade.jpg"
    },
    {
      "name": "Probopass",
      "number": 473,
      "type": "rock/steel",
      "image": "images/probopass.jpg"
    },
    {
      "name": "Dusknoir",
      "number": 474,
      "type": "ghost",
      "image": "images/dusknoir.jpg"
    },
    {
      "name": "Froslass",
      "number": 475,
      "type": "ice/ghost",
      "image": "images/froslass.jpg"
    },
    {
      "name": "Rotom",
      "number": 476,
      "type": "electric/ghost",
      "image": "images/rotom.jpg"
    },
    {
      "name": "Uxie",
      "number": 477,
      "type": "psychic",
      "image": "images/uxie.jpg"
    },
    {
      "name": "Mesprit",
      "number": 478,
      "type": "psychic",
      "image": "images/mesprit.jpg"
    },
    {
      "name": "Azelf",
      "number": 479,
      "type": "psychic",
      "image": "images/azelf.jpg"
    },
    {
      "name": "Dialga",
      "number": 480,
      "type": "steel/dragon",
      "image": "images/dialga.jpg"
    },
    {
      "name": "Palkia",
      "number": 481,
      "type": "water/dragon",
      "image": "images/palkia.jpg"
    },
    {
      "name": "Heatran",
      "number": 482,
      "type": "fire/steel",
      "image": "images/heatran.jpg"
    },
    {
      "name": "Regigigas",
      "number": 483,
      "type": "normal",
      "image": "images/regigigas.jpg"
    },
    {
      "name": "Giratina",
      "number": 484,
      "type": "ghost/dragon",
      "image": "images/giratina.jpg"
    },
    {
      "name": "Cresselia",
      "number": 485,
      "type": "psychic",
      "image": "images/cresselia.jpg"
    },
    {
      "name": "Phione",
      "number": 486,
      "type": "water",
      "image": "images/phione.jpg"
    },
    {
      "name": "Manaphy",
      "number": 487,
      "type": "water",
      "image": "images/manaphy.jpg"
    },
    {
      "name": "Darkrai",
      "number": 488,
      "type": "dark",
      "image": "images/darkrai.jpg"
    },
    {
      "name": "Shaymin",
      "number": 489,
      "type": "grass",
      "image": "images/shaymin.jpg"
    },
    {
      "name": "Arceus",
      "number": 490,
      "type": "normal", // El tipo puede variar según la tabla, pero el base es Normal
      "image": "images/arceus.jpg"
    }
  ];
  return defaultData;
}

function getStoredList() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('Invalid JSON in storage; resetting', e);
    localStorage.removeItem(STORAGE_KEY);
    return null;
  }
}

function saveStoredList(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function ensureData() {
  let list = getStoredList();
  if (!list) {
    list = loadInitialData();
    saveStoredList(list);
  }
  return list;
}

/* Render list to DOM */
function renderList() {
  const list = ensureData();
  const container = document.getElementById('pokedex-list');
  if (!container) return;

  container.innerHTML = ''; // clear

  list.forEach((entry, index) => {
    const card = document.createElement('article');
    card.className = 'pokemon-card';
    card.setAttribute('role', 'article');
    // store searchable attributes
    card.dataset.name = entry.name;
    card.dataset.number = entry.number;

    const img = document.createElement('img');
    img.className = 'card-image';
    img.src = entry.image;
    img.alt = `${entry.name} image`;

    const body = document.createElement('div');
    body.className = 'card-body';

    const title = document.createElement('h4');
    title.className = 'card-title';
    title.textContent = `${entry.name}`;

    const meta = document.createElement('div');
    meta.className = 'card-meta';
    meta.textContent = `#${entry.number} • ${entry.type}`;

    body.appendChild(title);
    body.appendChild(meta);
    card.appendChild(img);
    card.appendChild(body);

    container.appendChild(card);
  });
}

/* Add new item to storage and re-render */
function addNewPokemon(pokemon) {
  if (!pokemon || !pokemon.name) return false;
  const list = ensureData();
  // prevent duplicate number
  const exists = list.some(item => Number(item.number) === Number(pokemon.number));
  if (exists) {
    alert('A Pokémon with that Pokédex number already exists.');
    return false;
  }

  // Normalize values
  const newEntry = {
    name: pokemon.name.trim(),
    number: Number(pokemon.number),
    type: pokemon.type,
    image: pokemon.image
  };

  list.unshift(newEntry); // newest first
  saveStoredList(list);
  renderList();
  return true;
}

/* Initialize module */
(function initCrudModule() {
  // on page load
  document.addEventListener('DOMContentLoaded', () => {
    ensureData();
    renderList();
  });

  // Listen for validated form submissions
  window.addEventListener('pokemon:add', (e) => {
    addNewPokemon(e.detail);
  });
})();