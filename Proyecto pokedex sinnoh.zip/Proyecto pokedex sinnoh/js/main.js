// Wait for the HTML content to be loaded
document.addEventListener('DOMContentLoaded', () => {
    // Select elements we need
    const menuIcon = document.querySelector('.menu-icon');
    const sideMenu = document.querySelector('.side-menu');

    // Check existence before attaching listeners
    if (menuIcon && sideMenu) {
        // Toggle the 'open' class on click
        menuIcon.addEventListener('click', () => {
            sideMenu.classList.toggle('open');
        });
    }
});